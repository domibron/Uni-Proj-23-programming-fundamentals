﻿using RougeGame.Core;

namespace ConsoleApp
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            
            // runds the application.
            RougeGameCore.RunGame();
        }
    }
}